# pizza-delivery-managment
This project is platform dependent
